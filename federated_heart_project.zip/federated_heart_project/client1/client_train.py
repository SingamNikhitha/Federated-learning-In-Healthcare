# client_train.py
import pandas as pd
import numpy as np
import joblib
from model import HeartDiseaseModel

def train_model(data_path, save_path):
    # Load data
    df = pd.read_csv(data_path)
    X = df.drop("target", axis=1).values
    y = df["target"].values

    # Train model
    model = HeartDiseaseModel()
    model.train(X, y)

    # Save weights (coef and intercept)
    coef, intercept = model.get_weights()
    weights = {"coef": coef.tolist(), "intercept": intercept.tolist()}
    joblib.dump(weights, save_path)

    print(f"✅ Training complete. Weights saved to client_weights.pth")
    return weights

if __name__ == "__main__":
    # For client1:
    train_model("../data/client1.csv", "client_weights.pth")
    # For client2, change paths accordingly
