# federated_web/urls.py
from django.contrib import admin
from django.urls import path
from core import views  # Make sure this is the correct import

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.predict_heart_disease, name='predict'),  # FIXED NAME HERE
]
