# generate_global_model_weights.py
import pickle
import numpy as np
from sklearn.linear_model import LogisticRegression

# Sample model with dummy training to initialize weights
X_dummy = np.array([[0]*13, [1]*13])
y_dummy = np.array([0, 1])

model = LogisticRegression()
model.fit(X_dummy, y_dummy)

# Save the model weights
weights = {
    'coef': model.coef_,
    'intercept': model.intercept_
}

# Make sure this path matches the one expected in your views.py
with open('global_server/global_model_weights.pkl', 'wb') as f:
    print("✅ Global model weights generated and saved.")
