import torch
import joblib
import numpy as np
from model import HeartDiseaseModel
import os

def load_weights(path):
    try:
        print(f"Trying to load {path} using torch...")
        weights = torch.load(path)
        return weights
    except Exception as e:
        print(f"❌ torch.load failed: {e}")
        print(f"Trying to load {path} using joblib instead...")
        weights = joblib.load(path)
        return weights

# Load weights from both clients
client1_weights = load_weights("../client1/client_weights.pth")
client2_weights = load_weights("../client2/client2_weights.pth")

# Extract and convert
coef1 = np.array(client1_weights["coef"]).flatten()
coef2 = np.array(client2_weights["coef"]).flatten()
inter1 = np.array(client1_weights["intercept"]).flatten()
inter2 = np.array(client2_weights["intercept"]).flatten()

# Federated averaging
avg_coef = np.mean([coef1, coef2], axis=0)
avg_intercept = np.mean([inter1, inter2], axis=0)

# Set to global model
global_model = HeartDiseaseModel()
global_model.set_weights(avg_coef, avg_intercept)

# Save aggregated model weights
joblib.dump({"coef": avg_coef, "intercept": avg_intercept}, "global_model_weights.pkl")

print("\n✅ Global model aggregation completed.")
print("➡️ Saved as: global_model_weights.pkl")
