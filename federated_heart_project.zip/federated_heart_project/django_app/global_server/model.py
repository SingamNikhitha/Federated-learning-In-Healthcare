import numpy as np
from sklearn.linear_model import LogisticRegression

class HeartDiseaseModel:
    def __init__(self):
        self.model = LogisticRegression()
        self.is_fitted = False

    def set_weights(self, weights):
        """
        Expects weights to be a dictionary with keys: 'coef', 'intercept'
        """
        self.model.coef_ = np.array(weights['coef'])
        self.model.intercept_ = np.array(weights['intercept'])
        self.model.classes_ = np.array([0, 1])
        self.is_fitted = True

    def predict(self, X):
        if not self.is_fitted:
            raise ValueError("Model weights not set. Call set_weights first.")
        return self.model.predict(X)

def create_model():
    return LogisticRegression()
