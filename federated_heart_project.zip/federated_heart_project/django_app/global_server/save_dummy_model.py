# global_server/save_model.py
import pickle
from sklearn.linear_model import LogisticRegression
import numpy as np

# Create dummy data
X = np.array([[63,1,3,145,233,1,0,150,0,2.3,0,0,1],
              [45,0,2,130,230,0,1,160,1,1.5,2,1,2]])
y = np.array([1, 0])

# Train a simple model
model = LogisticRegression()
model.fit(X, y)

# Save model
with open('global_model_weights.pkl', 'wb') as f:
    pickle.dump(model, f)

print("✅ Dummy model saved successfully.")
