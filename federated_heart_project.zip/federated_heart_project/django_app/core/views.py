# core/views.py
from django.shortcuts import render
import pickle
import numpy as np
import os

MODEL_PATH = os.path.join('global_server', 'global_model_weights.pkl')

def predict_heart_disease(request):
    fields = ['age', 'sex', 'cp', 'trestbps', 'chol', 'fbs', 'restecg',
              'thalach', 'exang', 'oldpeak', 'slope', 'ca', 'thal']
    
    prediction = None
    message = None

    if request.method == 'POST':
        try:
            input_data = [float(request.POST.get(field)) for field in fields]

            if os.path.exists(MODEL_PATH):
                with open(MODEL_PATH, 'rb') as f:
                    model = pickle.load(f)
                result = model.predict([input_data])[0]
                prediction = "Heart Disease" if result == 1 else "No Heart Disease"
            else:
                message = "⚠️ Global model weights file not found. Please ensure training has been completed."

        except Exception as e:
            message = f"⚠️ Error during prediction: {str(e)}"

    return render(request, 'predict.html', {
        'fields': fields,
        'prediction': prediction,
        'message': message
    })
